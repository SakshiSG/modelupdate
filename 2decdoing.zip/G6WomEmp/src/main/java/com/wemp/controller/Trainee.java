package com.wemp.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.wemp.dao.TraineeDao;
import com.wemp.model.AddressModel;
import com.wemp.model.AdminInfo;
import com.wemp.model.CourseInfo;
import com.wemp.model.CourseModel;
import com.wemp.model.StatusModel;
import com.wemp.model.TraineeModel;
import com.wemp.service.TraineeService;

@Controller
public class Trainee {
@Autowired
TraineeDao edao;
@RequestMapping(value="/Register" , method = RequestMethod.POST)
public ModelAndView traineeInfo(@ModelAttribute TraineeModel tm,AddressModel am,CourseModel mo ,
		@RequestParam("file") MultipartFile file) {
	
	System.out.println("welcome to controller"+tm.getFname());
	System.out.println(mo.getCoursename());
	String strpass=tm.getPass();
	TraineeService ser= new  TraineeService();
	String encrp=ser.encripPass(strpass);
	tm.setPass(encrp);
	tm.setStatus("pending");
	System.out.println(am.getPin());
	
	int num= edao.saveData(tm,am,mo);
	
	String name="Birth Certificate";
	long rnum=edao.getRegnum(tm.getAadhar());
	System.out.println("for confirm"+rnum);
	   //Download Document
	
	if(num>0)
	{
		System.out.println("Inside file upload");
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "Uploaded Documents");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

			
						 String path=serverFile.getAbsolutePath();

				
			} catch (Exception e) {
				System.out.println("Exception Occureed");
			}
			
		} else {
			      System.out.println("File not select");
		}
		
		return new ModelAndView("confirm","regnum",rnum);
	    }
		
			
	else 
	{
		return new ModelAndView();
	}
		
}

@RequestMapping(value ="/ViewAllRecords/{gpt_rid}")
public ModelAndView getInformation(@PathVariable long gpt_rid)
{
	   
    	System.out.println("value of reid is "+gpt_rid);
    	//CourseInfo in=new CourseInfo();
	List<CourseInfo> info=edao.getInformation(gpt_rid);
    return new ModelAndView("viewapplicant","list",info);  
}

@RequestMapping("/information")
public ModelAndView getTrainee()
{
	System.out.println("hii im muneeb");
	List<AdminInfo> train = edao.getTraineeInfo();
	return new ModelAndView("applicantlist","data",train);
}
@RequestMapping("/viewStatus")
public ModelAndView getStatus(HttpServletRequest request)
{
    long rnum= Long.parseLong(request.getParameter("srid"));
  List<StatusModel> stat=edao.getStatusinfo(rnum);
  return new ModelAndView("showStatus","informa",stat);
}
}
