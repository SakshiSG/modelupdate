package com.wemp.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.wemp.dao.StatusDao;
import com.wemp.model.TraineeModel;
import com.wemp.service.TraineeService;

@Controller
public class Status 
{
	
@Autowired
StatusDao di;


	
	@RequestMapping("/Verify")
	public ModelAndView traineeLogin(@ModelAttribute TraineeModel tm)
	{
		System.out.println(tm.getUname());
		 String dbpass = di.logVerif(tm.getUname());
		 System.out.println(dbpass);
		 TraineeService ser=new TraineeService();
		 System.out.println("decriptedpass");
		 
		 String encpassw =ser.getEncppass(tm.getPass());
		 System.out.println(encpassw);
		 System.out.println("password from model class");
		 System.out.println(tm.getPass());
		 //tm.getPass().equals(decpass)
		
	     if( Objects.equals(dbpass, encpassw )){
	    	 return new ModelAndView("statuscheck");
	     }
	     else
	     {
	    	 System.out.println("no match");
	    	 return new ModelAndView("traineeReg");
	    	 
	     }
	
	}
	@RequestMapping("/forpas")
	public ModelAndView getForgotPass(HttpServletRequest req)
	{
		System.out.println("hiii");
		long adhar = Long.parseLong(req.getParameter("aadhar"));
		System.out.println(adhar);
		TraineeModel tm=new TraineeModel();
		tm.setAadhar(adhar);
		System.out.println(tm.getAadhar());
		String pass = di.getforgotPassword(tm.getAadhar());
		System.out.println(pass);
		TraineeService ser=new TraineeService();
		String decpass=ser.getdecPassword(pass);
		System.out.println(decpass);
		return new ModelAndView("forgetpassword","inform",decpass);
	}

}
