package com.wemp.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wemp.model.TraineeModel;

public class AdminDao {
	@Autowired
	JdbcTemplate jdbco;

	
     
	public JdbcTemplate getJdbco() {
		return jdbco;
	}



	public void setJdbco(JdbcTemplate jdbco) {
		this.jdbco = jdbco;
	}



	public int updateTrainee(TraineeModel mo)
	{
		
		String sql="update GR6_TRAINEES_PERSONAL set gpt_status ='"+mo.getStatus()+"' where gpt_rid ="+mo.getRid()+"";	
		return jdbco.update(sql);
	}
}
