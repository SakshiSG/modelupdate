package com.wemp.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wemp.model.TraineeModel;

public class StatusDao 
{
	@Autowired
	JdbcTemplate jdbcs;
	public JdbcTemplate getJdbcs() {
		return jdbcs;
	}
	public void setJdbcs(JdbcTemplate jdbcs) {
		this.jdbcs = jdbcs;
	}
	public String logVerif(String name)
	{
		Object obj=(String)jdbcs.queryForObject("select gpt_password from GR6_TRAINEES_PERSONAL where GPT_UNAME =?",new Object[] {name},String.class);
		String dbpass=(String)obj;
		return dbpass;
		
	}
	public String getforgotPassword(long adhar)
	{
		
		Object obj=(String)jdbcs.queryForObject("select GPT_PASSWORD from GR6_TRAINEES_PERSONAL where GPT_AADHAR = ?",new Object[] {adhar},String.class);
		String forgetpass=(String)obj;
		return forgetpass;
	}

}
