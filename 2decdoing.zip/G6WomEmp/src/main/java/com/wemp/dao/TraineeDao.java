package com.wemp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;  

import com.wemp.model.AddressModel;
import com.wemp.model.AdminInfo;
import com.wemp.model.CourseInfo;
import com.wemp.model.CourseModel;
import com.wemp.model.StatusModel;
import com.wemp.model.TraineeModel;

public class TraineeDao {
@Autowired
JdbcTemplate jdbc;

 public JdbcTemplate getJdbc() {
	return jdbc;
}
public void setJdbc(JdbcTemplate jdbc) {
	this.jdbc = jdbc;
}
public int saveData(TraineeModel tm,AddressModel am,CourseModel mo)
 {
	System.out.println(tm.getAadhar());
	 String str="insert into GR6_TRAINEES_PERSONAL values (GR6_TRAINEES_PERSONAL_SEQ.nextval,'"+tm.getFname()+"','"+tm.getMname()+"','"+tm.getLname()+"','"+tm.getDob()+"','"+tm.getEmail()+"','"+tm.getUname()+"','"+tm.getPass()+"',"+tm.getAadhar()+","+tm.getPhone()+",'"+tm.getStatus()+"')";
      jdbc.update(str);
      
      //System.out.println(tm.getPhone());
     // TraineeModel ad=getAadharnum(tm);
     // System.out.println(ad.getPhone());
     // HttpSession session=request.getSession();
      
      //long num=(Long) session.getAttribute("ridvalue");
      long num=getRid(tm);
     System.out.println(num);
      String str2="insert into GR6_ADDRESS_TRAINEES values ("+num+",'"+am.getCity()+"','"+am.getState()+"','"+am.getPin()+"')";
      jdbc.update(str2);
      System.out.println(num);
      String str3="insert into GR6_TRAINEES_COURSE values (GR6_TRAINEES_COURSE_SEQ.nextval,'"+mo.getCoursename()+"','"+mo.getNgo()+"',"+mo.getDuration()+","+num+")";
      return jdbc.update(str3);
      
 }
 /*public TraineeModel getAadharnum(TraineeModel l)
 {
	 String qry="Select * from gr6_personal_trainees where gpt_phone=?";
		TraineeModel td=(TraineeModel)jdbc.queryForObject(qry,new Object[]{l.getPhone()},
				new BeanPropertyRowMapper<TraineeModel>(TraineeModel.class));
		return td;
 }*/
public long getRid(TraineeModel adhar)
{
	Object obj=jdbc.queryForObject("select gpt_rid from GR6_TRAINEES_PERSONAL where GPT_AADHAR =?",new Object[] {adhar.getAadhar()},Long.class);
	long dbpass=(Long)obj;
	return dbpass;
}
public List<CourseInfo> getInformation(long regid)
{
	System.out.println("Inside List Function");
	System.out.println(regid);
	String sql="select * from (select p.GPT_RID,p.GPT_FIRSTNAME,p.GPT_MIDDLENAME,p.GPT_LASTNAME,p.GPT_DOB,p.GPT_EMAIL,p.GPT_UNAME,p.GPT_PASSWORD,p.GPT_AADHAR,p.GPT_PHONE,p.GPT_STATUS, c.GTC_COURSE_NAME,c.GTC_NGO_NAME,c.GTC_DURATION from GR6_TRAINEES_PERSONAL p inner join  GR6_TRAINEES_COURSE c on p.GPT_RID=c.GPT_RID) where GPT_RID ="+regid+"";
	return jdbc.query(sql,new ResultSetExtractor<List<CourseInfo>>()
	{  
		 public List<CourseInfo> extractData(ResultSet rs) throws SQLException, DataAccessException {  
			  System.out.println("inside ResultSetExtractor");
			  List<CourseInfo> list=new ArrayList<CourseInfo>();
			  
			  while(rs.next()){  
			CourseInfo e=new CourseInfo();
			//System.out.println(rs.getLong(1));
	        e.setGpt_rid(rs.getLong(1)); 
	        //System.out.println(rs.getString(2));
	        e.setGpt_firstname(rs.getString(2));
	        e.setGpt_middlename(rs.getString(3));
	        e.setGpt_lastname(rs.getString(4));
	        e.setGpt_dob(rs.getString(5));
	        e.setGpt_email(rs.getString(6));
	        e.setGpt_uname(rs.getString(7));
	        e.setGpt_password(rs.getString(8));
	        e.setGpt_aadhar(rs.getLong(9));
	        e.setGpt_phone(rs.getLong(10));
	        e.setGtp_status(rs.getString(11));
	        e.setGtc_course_name(rs.getString(12));
	        e.setGtc_ngo_name(rs.getString(13));
	       // System.out.println(rs.getString(13));
	        e.setGtc_duration(rs.getInt(14));
	        list.add(e);
			  }
			return list;
		}
	    }
	);  
	
}
   public List<AdminInfo> getTraineeInfo()
   {
	   String sqlq="select GPT_RID,GPT_FIRSTNAME,GPT_MIDDLENAME,GPT_LASTNAME from  GR6_TRAINEES_PERSONAL";
	   return jdbc.query(sqlq,new ResultSetExtractor<List<AdminInfo>>()
			   {
		   public List<AdminInfo> extractData(ResultSet rs) throws SQLException, DataAccessException {  
				  System.out.println("inside ResultSetExtractor");
				  List<AdminInfo> lt=new ArrayList<AdminInfo>();
				  
				  while(rs.next()){  
					  AdminInfo em=new AdminInfo();
				System.out.println(rs.getLong(1));
		        em.setGpt_rid(rs.getLong(1)); 
		        System.out.println(rs.getString(2));
		        em.setGpt_firstname(rs.getString(2));
		        em.setGpt_middlename(rs.getString(3));
		        em.setGpt_lastname(rs.getString(4));
		       
		        lt.add(em);
				  }
				return lt;
			}
			   }
	   );
   }
   public List<StatusModel> getStatusinfo(long regnum)
   {
	   System.out.println(regnum);
	   String sqlm = "select * from (select p.GPT_RID,p.GPT_FIRSTNAME,p.GPT_MIDDLENAME,p.GPT_LASTNAME,c.GTC_COURSE_NAME,c.GTC_NGO_NAME,p.GPT_STATUS from GR6_TRAINEES_PERSONAL p inner join  GR6_TRAINEES_COURSE c on p.GPT_RID=c.GPT_RID) where GPT_RID = "+regnum+"";
	   
	   return jdbc.query(sqlm,new ResultSetExtractor<List<StatusModel>>()
		{  
			 public List<StatusModel> extractData(ResultSet rs) throws SQLException, DataAccessException {  
				  System.out.println("inside ResultSetExtractor");
				  List<StatusModel> list=new ArrayList<StatusModel>();
				  
				  while(rs.next()){  
				StatusModel si=new StatusModel();
				//System.out.println(rs.getLong(1));
		        si.setGpt_rid(rs.getLong(1)); 
		        //System.out.println(rs.getString(2));
		        si.setGpt_firstname(rs.getString(2));
		        si.setGpt_middlename(rs.getString(3));
		        si.setGpt_lastname(rs.getString(4));
		        si.setGtc_course_name(rs.getString(5));
		        si.setGtc_ngo_name(rs.getString(6));
		        si.setGpt_status(rs.getString(7));
		       // System.out.println(rs.getString(13));
	
		        list.add(si);
				  }
				return list;
			}
		    }
		);  

   }
   
   public long getRegnum(long adhar)
   {
   	Object obj=jdbc.queryForObject("select gpt_rid from GR6_TRAINEES_PERSONAL where GPT_AADHAR =?",new Object[] {adhar},Long.class);
   	long regnum=(Long)obj;
   	return regnum;
   }
   
 
}
